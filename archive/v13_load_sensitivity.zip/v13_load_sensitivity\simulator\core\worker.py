from __future__ import annotations

import simpy

from simulator.config import SimConfig
from simulator.core.request import Request


class WorkerNode:
    def __init__(self, env: simpy.Environment, worker_id: int, config: SimConfig) -> None:
        self.env = env
        self.worker_id = worker_id
        self.config = config
        self.resource = simpy.Resource(env, capacity=1)
        self.slowdown_factor: float = 1.0
        self.completed: list[Request] = []

    @property
    def service_time(self) -> float:
        return self.config.t_base * self.slowdown_factor

    def process(self, request: Request) -> simpy.events.Event:
        return self.env.process(self._handle(request))

    def _handle(self, request: Request) -> simpy.events.Event:
        with self.resource.request() as req:
            yield req
            if request.cancelled:
                return
            request.start_time = self.env.now
            request.worker_id = self.worker_id
            yield self.env.timeout(self.service_time)
            request.end_time = self.env.now
            if not request.is_probe:
                self.completed.append(request)
