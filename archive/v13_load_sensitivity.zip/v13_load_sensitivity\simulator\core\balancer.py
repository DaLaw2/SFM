from __future__ import annotations

import numpy as np

from simulator.core.worker import WorkerNode


class LoadBalancer:
    def __init__(self, workers: list[WorkerNode], rng: np.random.Generator) -> None:
        self.workers = workers
        self.rng = rng
        self._weights: dict[int, float] = {w.worker_id: 1.0 for w in workers}
        self._excluded: set[int] = set()

    def select_worker(self) -> WorkerNode:
        available = [w for w in self.workers if w.worker_id not in self._excluded]
        if not available:
            # Fallback: pick from non-excluded with zero weight, or truly all as last resort
            available = [w for w in self.workers if self._weights.get(w.worker_id, 1.0) > 0]
            if not available:
                available = self.workers

        if len(available) == 1:
            return available[0]

        weights = np.array([self._weights.get(w.worker_id, 1.0) for w in available])
        total = weights.sum()
        if total <= 0:
            probs = np.ones(len(available)) / len(available)
        else:
            probs = weights / total

        k = min(2, len(available))
        idxs = self.rng.choice(len(available), size=k, replace=False, p=probs)
        candidates = [available[i] for i in idxs]

        return min(candidates, key=lambda w: len(w.resource.queue) + len(w.resource.users))

    def update_weights(self, weights: dict[int, float]) -> None:
        self._weights.update(weights)

    def exclude_worker(self, worker_id: int) -> None:
        self._excluded.add(worker_id)

    def include_worker(self, worker_id: int) -> None:
        self._excluded.discard(worker_id)
