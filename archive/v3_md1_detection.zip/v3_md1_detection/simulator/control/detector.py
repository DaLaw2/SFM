from __future__ import annotations

import numpy as np

from simulator.control.monitor import SystemMetrics


class Detector:
    # Minimum severity floor: ignore noise below this value.
    MIN_SEVERITY = 0.05

    # G1: M/D/1 expected latency is used as the baseline instead of peer
    # median.  A node is only considered faulty when its observed latency
    # significantly exceeds the queueing-theory prediction for the current
    # load level.  This prevents false positives during overload (S3).
    #
    # Baseline uses M/D/1 mean sojourn time directly (not P99 estimate).
    # At moderate load, the median is a better baseline; at high load, the
    # M/D/1 mean dominates and prevents false positives from queueing noise.
    # MIN_FAULT_RATIO: node must exceed baseline by this factor to be flagged.
    MIN_FAULT_RATIO = 1.4

    def __init__(self, t_base: float = 0.01) -> None:
        self.t_base = t_base

    @staticmethod
    def _md1_expected_latency(t_base: float, rho: float) -> float:
        """M/D/1 mean sojourn time: service_time + wait.

        Wait = rho / (2 * mu * (1 - rho)), where mu = 1/t_base.
        """
        rho = min(rho, 0.99)  # cap to avoid division by zero
        if rho <= 0:
            return t_base
        wait = (rho * t_base) / (2.0 * (1.0 - rho))
        return t_base + wait

    def compute_severities(self, metrics: SystemMetrics, spare_capacity: float = 1.0) -> dict[int, float]:
        node_metrics = metrics.node_metrics
        if not node_metrics:
            return {}

        latencies = {
            wid: nm.p99 for wid, nm in node_metrics.items() if nm.p99 > 0
        }

        if len(latencies) < 2:
            return {wid: 0.0 for wid in node_metrics}

        # G1: Compute M/D/1 mean sojourn time as baseline.  We compare this
        # mean against observed P99; the MIN_FAULT_RATIO (1.4) compensates
        # for the mean-vs-P99 gap, so only true faults exceed the threshold.
        rho = min(0.99, max(0.0, 1.0 - spare_capacity))
        expected_mean = self._md1_expected_latency(self.t_base, rho)
        # Use max(M/D/1 mean, median) — at low load median is more stable,
        # at high load M/D/1 dominates and absorbs queueing variance.
        median_lat = float(np.median(list(latencies.values())))
        baseline = max(expected_mean, median_lat)

        severities: dict[int, float] = {}
        for wid in node_metrics:
            node_lat = latencies.get(wid, 0.0)
            if node_lat <= 0 or node_lat <= baseline * self.MIN_FAULT_RATIO:
                severities[wid] = 0.0
            else:
                sev = 1.0 - (baseline / node_lat)
                sev = max(0.0, min(sev, 0.999))
                if sev < self.MIN_SEVERITY:
                    sev = 0.0
                severities[wid] = sev

        return severities
