from __future__ import annotations

from dataclasses import dataclass, field

from simulator.config import StrategyConfig
from simulator.control import Strategy


@dataclass
class SelectorOutput:
    strategy_map: dict[int, Strategy]
    weight_map: dict[int, float]
    hedge_remaining: dict[int, bool] = field(default_factory=dict)


class StrategySelector:
    def __init__(self, node_ids: list[int], config: StrategyConfig | None = None) -> None:
        self.cfg = config or StrategyConfig()
        self._node_ids = node_ids
        self.strategy_map: dict[int, Strategy] = {
            wid: Strategy.NORMAL for wid in node_ids
        }
        self._de_escalation_count: dict[int, int] = {wid: 0 for wid in node_ids}

    def select(
        self,
        severities: dict[int, float],
        slo_dist: float,
        spare: float,
    ) -> SelectorOutput:
        urgency = max(0.0, 1.0 - slo_dist)

        # M2: Load-aware theta_spec — raise the speculation threshold when
        # spare capacity is low, preventing hedges from overloading healthy
        # workers at high utilization.  Factor ranges from 1.0 (plenty of
        # spare) to 3.0 (no spare at all).
        load_factor = 1.0 + 2.0 * max(0.0, 1.0 - spare / max(self.cfg.spare_min, 0.01))
        t_spec = self.cfg.theta_spec * load_factor * (1.0 - 0.5 * urgency)
        t_shed = self.cfg.theta_shed * (1.0 - 0.4 * urgency)
        t_iso = self.cfg.theta_iso * (1.0 - 0.3 * urgency)

        thresholds = {
            Strategy.NORMAL: 0.0,
            Strategy.SPECULATE: t_spec,
            Strategy.SHED: t_shed,
            Strategy.ISOLATE: t_iso,
        }

        new_map: dict[int, Strategy] = {}

        for wid, sev in severities.items():
            cur = self.strategy_map.get(wid, Strategy.NORMAL)

            if sev >= t_iso:
                target = Strategy.ISOLATE
            elif sev >= t_shed:
                target = Strategy.SHED
            elif sev >= t_spec:
                # M4: Cost-benefit gate — only speculate if there's enough
                # spare capacity; otherwise skip to SHED (which doesn't add
                # load) or stay NORMAL if severity is marginal.
                if spare > self.cfg.spare_min:
                    target = Strategy.SPECULATE
                elif sev >= t_shed * 0.8:
                    target = Strategy.SHED
                else:
                    target = Strategy.NORMAL
            else:
                target = Strategy.NORMAL

            if target > cur:
                new_map[wid] = target
                self._de_escalation_count[wid] = 0
            elif target < cur:
                if target == Strategy.NORMAL:
                    check_threshold = t_spec
                else:
                    check_threshold = thresholds.get(target, 0.0)
                if sev < check_threshold - self.cfg.hysteresis:
                    self._de_escalation_count[wid] = self._de_escalation_count.get(wid, 0) + 1
                    if self._de_escalation_count[wid] >= self.cfg.debounce:
                        de_esc = _de_escalate(cur)
                        # Skip SPECULATE when no spare (M4 consistency)
                        if de_esc == Strategy.SPECULATE and spare <= self.cfg.spare_min:
                            de_esc = Strategy.NORMAL
                        new_map[wid] = de_esc
                        self._de_escalation_count[wid] = 0
                    else:
                        new_map[wid] = cur
                else:
                    self._de_escalation_count[wid] = 0
                    new_map[wid] = cur
            else:
                new_map[wid] = cur
                self._de_escalation_count[wid] = 0

            # Emergency override — respect M4: skip SPECULATE when no spare
            if slo_dist < 0 and sev > t_spec:
                escalated = _escalate(cur)
                if escalated == Strategy.SPECULATE and spare <= self.cfg.spare_min:
                    escalated = Strategy.SHED
                if escalated > new_map[wid]:
                    new_map[wid] = escalated

        # G2: Capacity-aware isolation budget — only isolate nodes if the
        # remaining workers can handle the load without exceeding a safe
        # utilization threshold (max_isolation_fraction repurposed as max rho).
        # Sort by severity descending; greedily allow isolation while safe.
        n_total = len(self._node_ids)
        max_rho = 1.0 - self.cfg.max_isolation_fraction  # 0.25 → rho cap 0.75... too strict
        # Use spare as proxy: if isolating K nodes would leave remaining
        # workers above 90% utilization, downgrade to SHED.
        isolated_wids = [wid for wid, s in new_map.items() if s == Strategy.ISOLATE]
        if isolated_wids:
            isolated_wids.sort(key=lambda w: severities.get(w, 0.0), reverse=True)
            n_non_isolated = n_total - len(isolated_wids)
            if n_non_isolated > 0:
                # Estimate remaining utilization after isolation
                remaining_rho = (1.0 - spare) * n_total / n_non_isolated
                if remaining_rho > 0.9:
                    # Too risky — only keep as many as we can afford
                    # Find max K such that (1-spare)*N/(N-K) <= 0.9
                    current_rho = 1.0 - spare
                    max_k = max(0, int(n_total - current_rho * n_total / 0.9))
                    for wid in isolated_wids[max_k:]:
                        new_map[wid] = Strategy.SHED

        self.strategy_map = new_map

        weight_map: dict[int, float] = {}
        hedge_remaining: dict[int, bool] = {}
        for wid in severities:
            strat = new_map.get(wid, Strategy.NORMAL)
            if strat == Strategy.ISOLATE:
                weight_map[wid] = 0.0
            elif strat == Strategy.SHED:
                weight_map[wid] = max(self.cfg.w_min, 1.0 - severities.get(wid, 0.0))
            else:
                weight_map[wid] = 1.0

        return SelectorOutput(
            strategy_map=new_map,
            weight_map=weight_map,
            hedge_remaining=hedge_remaining,
        )


def _escalate(s: Strategy) -> Strategy:
    if s == Strategy.NORMAL:
        return Strategy.SPECULATE
    if s == Strategy.SPECULATE:
        return Strategy.SHED
    if s == Strategy.SHED:
        return Strategy.ISOLATE
    return Strategy.ISOLATE


def _de_escalate(s: Strategy) -> Strategy:
    if s == Strategy.ISOLATE:
        return Strategy.SHED
    if s == Strategy.SHED:
        return Strategy.SPECULATE
    if s == Strategy.SPECULATE:
        return Strategy.NORMAL
    return Strategy.NORMAL
