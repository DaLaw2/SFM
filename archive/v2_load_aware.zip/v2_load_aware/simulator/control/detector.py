from __future__ import annotations

import numpy as np

from simulator.control.monitor import SystemMetrics


class Detector:
    # Minimum severity floor: ignore noise below this value.
    # Without this, ~50% of nodes always show non-zero severity
    # (those above median), triggering false SPECULATE cascades.
    MIN_SEVERITY = 0.05

    # Minimum absolute latency ratio: node must be at least this much
    # slower than the median to be considered degraded.
    MIN_LATENCY_RATIO = 1.2

    # M5: At high load, natural queueing variance inflates latency ratios,
    # causing false positives.  Scale MIN_LATENCY_RATIO up when spare
    # capacity is low.
    MAX_LATENCY_RATIO = 2.0

    def compute_severities(self, metrics: SystemMetrics, spare_capacity: float = 1.0) -> dict[int, float]:
        # M5: Interpolate latency ratio threshold based on spare capacity.
        # spare=1.0 -> MIN_LATENCY_RATIO (1.2), spare=0.0 -> MAX_LATENCY_RATIO (2.0)
        load_signal = min(1.0, max(0.0, 1.0 - spare_capacity))
        ratio_threshold = self.MIN_LATENCY_RATIO + (
            self.MAX_LATENCY_RATIO - self.MIN_LATENCY_RATIO
        ) * load_signal
        node_metrics = metrics.node_metrics
        if not node_metrics:
            return {}

        latencies = {
            wid: nm.p99 for wid, nm in node_metrics.items() if nm.p99 > 0
        }

        if len(latencies) < 2:
            return {wid: 0.0 for wid in node_metrics}

        median_lat = float(np.median(list(latencies.values())))

        severities: dict[int, float] = {}
        for wid in node_metrics:
            node_lat = latencies.get(wid, 0.0)
            if node_lat <= 0 or node_lat <= median_lat * ratio_threshold:
                severities[wid] = 0.0
            else:
                sev = 1.0 - (median_lat / node_lat)
                sev = max(0.0, min(sev, 0.999))
                # Filter noise: severity below floor is treated as zero
                if sev < self.MIN_SEVERITY:
                    sev = 0.0
                severities[wid] = sev

        return severities
