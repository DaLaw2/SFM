[project]
name = "slow-fault-simulator"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = ["simpy>=4.0", "numpy", "pandas"]

[tool.setuptools.packages.find]
include = ["simulator*"]

[project.optional-dependencies]
plot = ["matplotlib"]
