from __future__ import annotations

from dataclasses import dataclass, field

from simulator.config import StrategyConfig
from simulator.control import Strategy


@dataclass
class SelectorOutput:
    strategy_map: dict[int, Strategy]
    weight_map: dict[int, float]
    hedge_remaining: dict[int, bool] = field(default_factory=dict)


class StrategySelector:
    def __init__(self, node_ids: list[int], config: StrategyConfig | None = None) -> None:
        self.cfg = config or StrategyConfig()
        self.strategy_map: dict[int, Strategy] = {
            wid: Strategy.NORMAL for wid in node_ids
        }
        self._de_escalation_count: dict[int, int] = {wid: 0 for wid in node_ids}

    def select(
        self,
        severities: dict[int, float],
        slo_dist: float,
        spare: float,
    ) -> SelectorOutput:
        urgency = max(0.0, 1.0 - slo_dist)

        t_spec = self.cfg.theta_spec * (1.0 - 0.5 * urgency)
        t_shed = self.cfg.theta_shed * (1.0 - 0.4 * urgency)
        t_iso = self.cfg.theta_iso * (1.0 - 0.3 * urgency)

        thresholds = {
            Strategy.NORMAL: 0.0,
            Strategy.SPECULATE: t_spec,
            Strategy.SHED: t_shed,
            Strategy.ISOLATE: t_iso,
        }

        new_map: dict[int, Strategy] = {}

        for wid, sev in severities.items():
            cur = self.strategy_map.get(wid, Strategy.NORMAL)

            if sev >= t_iso:
                target = Strategy.ISOLATE
            elif sev >= t_shed:
                target = Strategy.SHED
            elif sev >= t_spec:
                target = Strategy.SPECULATE if spare > self.cfg.spare_min else Strategy.SHED
            else:
                target = Strategy.NORMAL

            if target > cur:
                new_map[wid] = target
                self._de_escalation_count[wid] = 0
            elif target < cur:
                if target == Strategy.NORMAL:
                    check_threshold = t_spec
                else:
                    check_threshold = thresholds.get(target, 0.0)
                if sev < check_threshold - self.cfg.hysteresis:
                    self._de_escalation_count[wid] = self._de_escalation_count.get(wid, 0) + 1
                    if self._de_escalation_count[wid] >= self.cfg.debounce:
                        new_map[wid] = _de_escalate(cur)
                        self._de_escalation_count[wid] = 0
                    else:
                        new_map[wid] = cur
                else:
                    self._de_escalation_count[wid] = 0
                    new_map[wid] = cur
            else:
                new_map[wid] = cur
                self._de_escalation_count[wid] = 0

            # Emergency override
            if slo_dist < 0 and sev > t_spec:
                escalated = _escalate(cur)
                if escalated > new_map[wid]:
                    new_map[wid] = escalated

        self.strategy_map = new_map

        weight_map: dict[int, float] = {}
        hedge_remaining: dict[int, bool] = {}
        for wid in severities:
            strat = new_map.get(wid, Strategy.NORMAL)
            if strat == Strategy.ISOLATE:
                weight_map[wid] = 0.0
            elif strat == Strategy.SHED:
                weight_map[wid] = max(self.cfg.w_min, 1.0 - severities.get(wid, 0.0))
                hedge_remaining[wid] = spare > self.cfg.spare_min
            else:
                weight_map[wid] = 1.0

        return SelectorOutput(
            strategy_map=new_map,
            weight_map=weight_map,
            hedge_remaining=hedge_remaining,
        )


def _escalate(s: Strategy) -> Strategy:
    if s == Strategy.NORMAL:
        return Strategy.SPECULATE
    if s == Strategy.SPECULATE:
        return Strategy.SHED
    if s == Strategy.SHED:
        return Strategy.ISOLATE
    return Strategy.ISOLATE


def _de_escalate(s: Strategy) -> Strategy:
    if s == Strategy.ISOLATE:
        return Strategy.SHED
    if s == Strategy.SHED:
        return Strategy.SPECULATE
    if s == Strategy.SPECULATE:
        return Strategy.NORMAL
    return Strategy.NORMAL
