from __future__ import annotations

import numpy as np

from simulator.control.monitor import SystemMetrics


class Detector:
    # Minimum severity floor: ignore noise below this value.
    # Without this, ~50% of nodes always show non-zero severity
    # (those above median), triggering false SPECULATE cascades.
    MIN_SEVERITY = 0.05

    # Minimum absolute latency ratio: node must be at least this much
    # slower than the median to be considered degraded.
    MIN_LATENCY_RATIO = 1.2

    def compute_severities(self, metrics: SystemMetrics) -> dict[int, float]:
        node_metrics = metrics.node_metrics
        if not node_metrics:
            return {}

        latencies = {
            wid: nm.p99 for wid, nm in node_metrics.items() if nm.p99 > 0
        }

        if len(latencies) < 2:
            return {wid: 0.0 for wid in node_metrics}

        median_lat = float(np.median(list(latencies.values())))

        severities: dict[int, float] = {}
        for wid in node_metrics:
            node_lat = latencies.get(wid, 0.0)
            if node_lat <= 0 or node_lat <= median_lat * self.MIN_LATENCY_RATIO:
                severities[wid] = 0.0
            else:
                sev = 1.0 - (median_lat / node_lat)
                sev = max(0.0, min(sev, 0.999))
                # Filter noise: severity below floor is treated as zero
                if sev < self.MIN_SEVERITY:
                    sev = 0.0
                severities[wid] = sev

        return severities
