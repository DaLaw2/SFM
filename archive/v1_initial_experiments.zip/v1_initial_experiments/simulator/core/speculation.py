from __future__ import annotations

import simpy

from simulator.config import SimConfig
from simulator.control import Strategy
from simulator.core.balancer import LoadBalancer
from simulator.core.request import Request
from simulator.core.worker import WorkerNode


class SpeculationManager:
    def __init__(
        self,
        env: simpy.Environment,
        config: SimConfig,
        balancer: LoadBalancer,
        workers: list[WorkerNode],
    ) -> None:
        self.env = env
        self.config = config
        self.balancer = balancer
        self.workers = {w.worker_id: w for w in workers}
        self.strategy_map: dict[int, Strategy] = {}
        self.hedge_remaining: bool = True
        self.node_p50: dict[int, float] = {}
        self.hedge_count: int = 0
        self.cancel_count: int = 0
        self._next_hedge_id: int = 0

    def should_hedge(self, worker_id: int) -> bool:
        strat = self.strategy_map.get(worker_id, Strategy.NORMAL)
        if strat == Strategy.SPECULATE:
            return True
        if strat == Strategy.SHED and self.hedge_remaining:
            return True
        return False

    def submit_with_hedge(
        self,
        request: Request,
        slow_worker_id: int,
        hedge_delay: float | None = None,
    ) -> simpy.events.Event:
        """Submit request to slow worker AND a hedge copy to a healthy worker.

        Returns a SimPy event that triggers when the first response arrives.
        The other is cancelled.
        """
        slow_worker = self.workers[slow_worker_id]
        if hedge_delay is None:
            hedge_delay = self.node_p50.get(slow_worker_id, self.config.t_base)
        return self.env.process(self._hedge_process(request, slow_worker, hedge_delay))

    def dispatch_hedged(
        self, request: Request, primary_worker: WorkerNode
    ) -> simpy.events.Event:
        hedge_delay = self.node_p50.get(primary_worker.worker_id, self.config.t_base)
        return self.env.process(self._hedge_process(request, primary_worker, hedge_delay))

    def _hedge_process(
        self, request: Request, primary_worker: WorkerNode, hedge_delay: float
    ) -> simpy.events.Event:
        self._next_hedge_id += 1
        hedge_request = Request(
            id=request.id,
            arrival_time=request.arrival_time,
            is_hedge=True,
        )

        # Start primary immediately
        primary_event = primary_worker.process(request)

        # Wait hedge_delay then dispatch hedge copy to a healthy worker
        if hedge_delay > 0:
            yield self.env.timeout(hedge_delay)

        if request.end_time > 0:
            # Primary already completed during delay
            return

        healthy_worker = self._pick_healthy_worker(primary_worker.worker_id)
        if healthy_worker is None:
            return

        self.hedge_count += 1
        hedge_event = healthy_worker.process(hedge_request)

        # Wait for either to complete
        result = yield primary_event | hedge_event

        # Cancel the slower one
        if request.end_time > 0 and hedge_request.end_time <= 0:
            hedge_request.cancelled = True
            self.cancel_count += 1
        elif hedge_request.end_time > 0 and request.end_time <= 0:
            request.cancelled = True
            self.cancel_count += 1
            # Copy timing from hedge to primary for metric purposes
            request.start_time = hedge_request.start_time
            request.end_time = hedge_request.end_time
            request.worker_id = hedge_request.worker_id

    def _pick_healthy_worker(self, exclude_id: int) -> WorkerNode | None:
        candidates = [
            w for wid, w in self.workers.items()
            if wid != exclude_id
            and self.strategy_map.get(wid, Strategy.NORMAL) == Strategy.NORMAL
        ]
        if not candidates:
            return None
        return min(
            candidates,
            key=lambda w: len(w.resource.queue) + len(w.resource.users),
        )
